let currentPlayer = 'X';
const boardState = Array(9).fill(null);

const createBoard = () => {
    const gameBoard = document.getElementById('gameBoard');
    gameBoard.innerHTML = '';
    for (let i = 0; i < 9; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.dataset.index = i;
        cell.addEventListener('click', handleClick);
        gameBoard.appendChild(cell);
    }
};

const restartGame = () => {
    boardState.fill(null); // Reset the board state
    currentPlayer = 'X'; // Reset the current player
    const winnerPopup = document.getElementById('winnerPopup');
    winnerPopup.style.display = 'none'; // Hide the popup
    createBoard(); // Recreate the game board
};

const checkWinner = () => {
    const winningCombinations = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    for (const combination of winningCombinations) {
        const [a, b, c] = combination;
        if (boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c]) {
            return boardState[a];
        }
    }

    return boardState.every(cell => cell) ? 'Draw' : null;
};

const handleClick = (e) => {
    const cell = e.target;
    const index = cell.dataset.index;

    if (!boardState[index]) {
        boardState[index] = currentPlayer;
        cell.textContent = currentPlayer;
        cell.style.color = currentPlayer === 'X' ? 'red' : 'blue';
        cell.classList.add('taken');

        const winner = checkWinner();

        if (winner) {
            const winnerMessage = document.getElementById('winnerMessage');
            const winnerPopup = document.getElementById('winnerPopup');
            winnerMessage.textContent = winner === 'Draw' ? 'It\'s a Draw!' : `${winner} Wins!`;
            winnerPopup.style.display = 'block';
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    }
};

// Attach the restartGame function to the Play Again button
document.addEventListener('DOMContentLoaded', () => {
    const playAgainButton = document.querySelector('#winnerPopup button');
    playAgainButton.addEventListener('click', restartGame);
    createBoard();
});
